<?php  
  if (isset($_GET['page'])) {
    if ($_GET['page'] == "arsip") {
      include 'page/arsip/arsip.php';
    } elseif ($_GET['page'] == "arsip-bulanan") {
      include 'page/arsip/arsip-bulanan.php';
    } elseif ($_GET['page'] == "tambah-arsip") {
      include 'page/arsip/tambah-arsip.php';
    } elseif ($_GET['page'] == "ubah-arsip") {
      include 'page/arsip/ubah-arsip.php';
    } elseif ($_GET['page'] == "proses-ubah-arsip") {
      include 'page/arsip/proses-ubah-arsip.php';
    } elseif ($_GET['page'] == "detail-arsip") {
      include 'page/arsip/detail-arsip.php';
    } elseif ($_GET['page'] == "hapus-arsip") {
      include 'page/arsip/hapus-arsip.php';

    } elseif ($_GET['page'] == "hapus-dok") {
      include 'page/arsip/hapus-dok.php';
    

    } elseif ($_GET['page'] == "pencarian") {
      include 'page/pencarian.php';


    } elseif ($_GET['page'] == "saya") {
      include 'page/profil/saya/saya.php';
    } elseif ($_GET['page'] == "ubah-saya") {
      include 'page/profil/saya/ubah-saya.php';
    } elseif ($_GET['page'] == "proses-ubah-saya") {
      include 'page/profil/saya/proses-ubah-saya.php';
    } elseif ($_GET['page'] == "detail-saya") {
      include 'page/profil/saya/detail-saya.php';


    } elseif ($_GET['page'] == "perusahaan") {
      include 'page/profil/perusahaan/perusahaan.php';
    } elseif ($_GET['page'] == "ubah-perusahaan") {
      include 'page/profil/perusahaan/ubah-perusahaan.php';
    } 
  } else {
      include 'home.php';
  }
?>