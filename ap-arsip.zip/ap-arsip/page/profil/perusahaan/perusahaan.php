<!-- Begin Page Content -->
<div class="container-fluid">
  <?php  
    $query = $koneksi->query("SELECT * FROM perusahaan ORDER BY id_perusahaan DESC LIMIT 1");
    $data = $query->fetch_assoc();
  ?>

  <div class="card">
    <div class="card-header">
      <h1 class="h3 mb-0 text-gray-800">
        Profil Instansi 
        <?php if($_SESSION['user']['level']=='admin') : ?>
        <a href="?page=ubah-perusahaan&id_perusahaan=<?php echo $data['id_perusahaan']; ?>" class="btn btn-sm btn-success"><span class="fa fa-fw fa-edit"></span> Ubah Profil</a>
        <?php else : ?>
          <div></div>
        <?php endif; ?>
      </h1>
    </div>
    <div class="card-body">
      <h4><?php echo $data['judul']; ?></h4>
      <p><?php echo $data['isi']; ?></p>
    </div>
  </div>
</div>
<!-- /.container-fluid -->
