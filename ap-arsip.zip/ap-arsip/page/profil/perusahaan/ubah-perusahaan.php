<?php if($_SESSION['user']['level']=='admin') : ?>
<!-- Begin Page Content -->
<div class="container-fluid">

  <div class="card">
    <div class="card-header">
      <h1 class="h3 mb-0 text-gray-800">Ubah Profil Instansi</h1>
    </div>
    <div class="card-body">
      <?php  
        $id_perusahaan = $_GET['id_perusahaan'];
        $query = $koneksi->query("SELECT * FROM perusahaan");
        $data = $query->fetch_assoc();
      ?>
      <form action="" method="post">
        <input type="hidden" name="id_perusahaan" value="<?php echo $data['id_perusahaan']; ?>">
        <div class="form-group">
          <label>Judul</label>
          <input type="text" name="judul" class="form-control col-md-6" value="<?php echo $data['judul']; ?>">
        </div>
        <div class="form-group">
          <textarea name="isi" class="ckeditor col-md-6"><?php echo $data['isi']; ?></textarea>
        </div>
        <div class="form-group">
          <button type="submit" name="simpan" class="btn btn-sm btn-info"><span class="fa fa-save"></span> Simpan</button>
          <a href="?page=perusahaan" class="btn btn-sm btn-danger"><span class="fa fa-arrow-left"></span> Kembali</a >
        </div>
      </form>
    </div>
  </div>

</div>
<!-- /.container-fluid_perusahaan -->
<?php  
  $id_perusahaan = $_GET['id_perusahaan'];
  $query = $koneksi->query("SELECT * FROM perusahaan WHERE id_perusahaan = $id_perusahaan");
  $data = $query->fetch_assoc();
?>
<?php 
  if (isset($_POST['simpan'])) {
    mysqli_query($koneksi,"UPDATE perusahaan SET 
    id_perusahaan = '$_POST[id_perusahaan]',
    judul = '$_POST[judul]',
    isi = '$_POST[isi]'
    WHERE id_perusahaan = '$_POST[id_perusahaan]'");
    echo 
    "<script>
      document.location='?page=perusahaan';
    </script>";
  }
?>
<?php else : ?>
<?php echo "<div class='container'>Anda tidak berhak !</div>"; ?>
<?php endif ?>