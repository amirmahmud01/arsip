<?php 
  error_reporting(0);
  $id = $_SESSION['user']['id'];
  $edit=mysqli_query($koneksi, "SELECT * FROM user WHERE id = $id");
  $data=mysqli_fetch_array($edit);
  $foto   = $_FILES['foto']['name'];
  if (empty($foto)){
    $query = mysqli_query($koneksi, "UPDATE user SET
      nama = '$_POST[nama]',
      username = '$_POST[username]',
      password    = '$_POST[password]',
      no_tlp    = '$_POST[no_tlp]'
      WHERE id = '$_POST[id]'");
    echo "<script>document.location='logout.php';</script>";
  }
  else{

    $hapus = $query = mysqli_query($koneksi, "SELECT * FROM user WHERE id='$_POST[id]'");
    $nama_foto=mysqli_fetch_array($hapus);
    $lokasi=$nama_foto['foto'];
    $hapus_foto="foto/$lokasi";
    unlink($hapus_foto);
    move_uploaded_file($_FILES['foto']['tmp_name'],'page/profil/saya/foto/'.$foto);
    $query = mysqli_query($koneksi, "UPDATE user SET 
      nama = '$_POST[nama]',
      username    = '$_POST[username]',
      password = '$_POST[password]',
      no_tlp = '$_POST[no_tlp]',
      foto = '$foto'
      WHERE id = '$_POST[id]'");
    if ($query > 0) {
      echo "<script>document.location='logout.php';</script>";
    }
  }
?>