<!-- Begin Page Content -->
<div class="container-fluid">

  <div class="card">
    <div class="card-header"><h1 class="h3 mb-0 text-gray-800">Ubah Profil Saya</h1></div>
    <div class="card-body">
      <form action="?page=proses-ubah-saya" method="post" enctype="multipart/form-data">
        <input type="hidden" name="id" value="<?php echo $_SESSION['user']['id']; ?>">
        <div class="form-group">
          <label>Nama Saya</label>
          <input type="text" name="nama" class="form-control col-md-6" value="<?php echo $_SESSION['user']['nama']; ?>">
        </div>
        <div class="form-group">
          <label>Username</label>
          <input type="text" name="username" class="form-control col-md-6" value="<?php echo $_SESSION['user']['username']; ?>">
        </div>
        <div class="form-group">
          <label>Password</label>
          <input type="password" name="password" class="form-control col-md-6" value="<?php echo $_SESSION['user']['password']; ?>">
        </div>
        <div class="form-group">
          <label>No Telepon</label>
          <input type="number" name="no_tlp" class="form-control col-md-6" value="<?php echo $_SESSION['user']['no_tlp']; ?>">
        </div>
        <div class="form-group">
          <label>Ubah Foto Profil</label>
          <input type="file" name="foto" class="form-control col-md-6">
          <img src="page/profil/saya/<?php echo $_SESSION['user']['foto']; ?>" alt="">
          <?php echo $_SESSION['user']['foto']; ?>
        </div>
        <div class="form-group">
          <button type="submit" name="simpan" class="btn btn-sm btn-info"><span class="fa fa-save"></span> Simpan</button>
          <a href="?page=saya" class="btn btn-sm btn-danger"><span class="fa fa-arrow-left"></span> Kembali</a >
        </div>
      </form>
    </div>
  </div>

</div>
<!-- /.container-fluid -->