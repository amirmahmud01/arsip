<!-- Begin Page Content -->
<div class="container-fluid">

  <div class="card">
    <div class="card-header">
      <h1 class="h3 mb-0 text-gray-800">
        Profil Saya 
        <a href="?page=ubah-saya&id<?php echo $_SESSION['user']['id']; ?>" class="btn btn-sm btn-success"><span class="fa fa-fw fa-edit"></span> Ubah Profil</a>
      </h1>
    </div>
    <div class="card-body">
      <img class="img-thumbnail" width="200" src="page/profil/saya/foto/<?php echo $_SESSION['user']['foto']; ?>" alt=""><br>
      <b><?php echo $_SESSION['user']['nama']; ?></b><br>
      Level : <?php echo $_SESSION['user']['level']; ?>
      <p>No Telepon : <?php echo $_SESSION['user']['no_tlp']; ?></p>
    </div>
  </div>
</div>
<!-- /.container-fluid -->
