<?php  
	$id = $_GET['id'];
	$query = $koneksi->query("DELETE FROM p16 WHERE id_p16 = $id");
	echo "<script>document.location='?page=p16';</script>";
?>