<?php if($_SESSION['user']['level']=='admin') : ?>
<!-- Begin Page Content -->
<div class="container-fluid">

  <div class="card">
    <div class="card-header"><h1 class="h3 mb-0 text-gray-800">Tambah Arsip</h1></div>
    <div class="card-body">
      <form action="" method="post" enctype="multipart/form-data">
        <div class="form-group">
          <label>Nama Arsip</label>
          <input type="text" name="nama" class="form-control col-md-6">
        </div>
        <div class="form-group">
          <label>Bulan</label>
          <select name="id_bulanan" class="form-control col-md-6">
            <?php  
              $query = $koneksi->query("SELECT * FROM bulanan");
              foreach($query as $bulan) :
            ?>
              <option value="<?php echo $bulan["id_bulanan"]; ?>"><?php echo $bulan["bulan"]; ?></option>
              option
            <?php endforeach; ?>

          </select>
        </div>
        <div class="form-group">
          <label>Upload File Arsip</label>
          <input type="file" name="file" class="form-control col-md-6">
        </div>
        <div class="form-group">
          <button type="submit" name="simpan" class="btn btn-sm btn-info"><span class="fa fa-fw fa-save"></span> Simpan</button>
          <a href="?page=arsip" class="btn btn-sm btn-danger"><span class="fa fa-fw fa-arrow-left"></span> Kembali</a >
        </div>
      </form>
    </div>
  </div>

</div>
<!-- /.container-fluid -->
<?php  
  error_reporting(0);
  if (isset($_POST['simpan'])) {
    $nama = $_POST['nama'];
    $id_bulanan = $_POST['id_bulanan'];
    $tanggal = date("Y-m-d");
    $file = $_FILES['file']['name'];

    $ekstensiarsip = ["jpg","png","jpeg","pdf","doc","docx","xls","xlsx"];
    $ekstensi = explode(".", $file);
    $ekstensi = strtolower(end($ekstensi));
    $uploadarsip = "ARSIP".date("Ymdhis").".".$ekstensi;

    if (!in_array($ekstensi, $ekstensiarsip)) {
      echo
        "<script>
      alert('Ekstensi file tidak sesuai !');
      document.location='';
      </script>";
        return false;
    }

    $query = $koneksi->query("INSERT INTO dokumen VALUES (null,'$nama','$id_bulanan','$tanggal','$uploadarsip')");
    move_uploaded_file($_FILES['file']['tmp_name'], "page/arsip/file/". $uploadarsip);
    echo "<script>document.location='?page=arsip';</script>";
  }
?>
<?php else : ?>
<?php echo "<div class='container'>Anda tidak berhak !</div>"; ?>
<?php endif ?>