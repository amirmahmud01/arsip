<?php  
    $id_p16 = $_GET["id"];
    $sub_bagian = htmlspecialchars(addslashes($_POST["sub_bagian"]));
    $jenis = htmlspecialchars(addslashes($_POST["jenis"]));
    $nomor_registrasi = htmlspecialchars(addslashes($_POST["nomor_registrasi"]));
    $nama_terdakwa = htmlspecialchars(addslashes($_POST["nama_terdakwa"]));
    $pasal = htmlspecialchars(addslashes($_POST["pasal"]));
    $jpu = htmlspecialchars(addslashes($_POST["jpu"]));
    $klasifikasi = htmlspecialchars(addslashes($_POST["klasifikasi"]));
    $status = htmlspecialchars(addslashes($_POST["status"]));
    $instansi_penyidik = htmlspecialchars(addslashes($_POST["instansi_penyidik"]));
    $dokumen = $_FILES["dokumen"]["name"];
    $keterangan = htmlspecialchars(addslashes($_POST["keterangan"]));

    $ekstensi = explode(".", $dokumen);
    $ekstensi = strtolower(end($ekstensi));
    $uploaddok = "DOK".date("Ymdhis").".".$ekstensi;

    $tanggal = date("Y-m-d");

    if ($dokumen == "") {
      $query = $koneksi->query("UPDATE p16 SET 
        sub_bagian = '$sub_bagian',
        jenis = '$jenis',
        nomor_registrasi = '$nomor_registrasi',
        nama_terdakwa = '$nama_terdakwa',
        pasal = '$pasal',
        jpu = '$jpu',
        klasifikasi = '$klasifikasi',
        status = '$status',
        instansi_penyidik = '$instansi_penyidik',
        keterangan = '$keterangan',
        '$tanggal'
        WHERE id_p16 = $id_p16
      ");
    } else {
      $query = $koneksi->query("UPDATE p16 SET 
        sub_bagian = '$sub_bagian',
        jenis = '$jenis',
        nomor_registrasi = '$nomor_registrasi',
        nama_terdakwa = '$nama_terdakwa',
        pasal = '$pasal',
        jpu = '$jpu',
        klasifikasi = '$klasifikasi',
        status = '$status',
        instansi_penyidik = '$instansi_penyidik',
        uploaddok = '$uploaddok',
        keterangan = '$keterangan',
        '$tanggal'
        WHERE id_p16 = $id_p16
      ");

      move_uploaded_file($_FILES['dokumen']['tmp_name'], "page/arsip/file/". $uploaddok);
    }

    echo "<script>document.location='?page=p16';</script>";
?>