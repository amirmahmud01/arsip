<?php if($_SESSION['user']['level']=='admin') : ?>
<!-- Begin Page Content -->
<div class="container-fluid">

  <div class="card">
    <div class="card-header"><h1 class="h3 mb-0 text-gray-800">Ubah Arsip</h1></div>
    <div class="card-body">
      <?php  
        $id = $_GET['id'];
        $query = $koneksi->query("SELECT * FROM dokumen JOIN bulanan ON dokumen.id_bulanan = bulanan.id_bulanan WHERE id = $id");
        $data = $query->fetch_assoc();
      ?>
      <form action="?page=proses-ubah-arsip" method="post" enctype="multipart/form-data">
        <input type="hidden" name="id" value="<?php echo $data['id']; ?>">
        <div class="form-group">
          <label>Nama Arsip</label>
          <input type="text" name="nama" class="form-control col-md-6" value="<?php echo $data['nama']; ?>">
        </div>
        <div class="form-group">
          <label>Bulan</label>
          <select name="id_bulanan" class="form-control col-md-6">
            <?php  
              $query = $koneksi->query("SELECT * FROM bulanan");
              foreach($query as $bulan) :
            ?>
              <option <?php if($bulan["id_bulanan"] == $data["id_bulanan"]) echo "selected"; ?> value="<?php echo $bulan["id_bulanan"]; ?>"><?php echo $bulan["bulan"]; ?></option>
              option
            <?php endforeach; ?>
          </select>
        </div>
        <div class="form-group">
          <label>Tanggal Pengarsipan</label>
          <input type="date" name="tanggal" class="form-control col-md-6" value="<?php echo $data['tanggal']; ?>">
        </div>
        <div class="form-group">
          <label>Ubah File Arsip</label>
          <input type="file" name="file" class="form-control col-md-6">
          File -> <?php echo $data['file']; ?>
        </div>
        <div class="form-group">
          <button type="submit" name="simpan" class="btn btn-sm btn-info"><span class="fa fa-save"></span> Simpan</button>
          <a href="?page=arsip" class="btn btn-sm btn-danger"><span class="fa fa-arrow-left"></span> Kembali</a >
        </div>
      </form>
    </div>
  </div>

</div>
<!-- /.container-fluid -->
<?php else : ?>
<?php echo "<div class='container'>Anda tidak berhak !</div>"; ?>
<?php endif ?>