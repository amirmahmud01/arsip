<?php if($_SESSION['user']['level']=='admin') : ?>
<?php 
  error_reporting(0);
  $id = $_GET['id'];
  $edit=mysqli_query($koneksi, "SELECT * FROM dokumen WHERE id = $id");
  $data=mysqli_fetch_array($edit);
  $file   = $_FILES['file']['name'];
  if (empty($file)){
    $query = mysqli_query($koneksi, "UPDATE dokumen SET
      nama = '$_POST[nama]',
      id_bulanan = '$_POST[id_bulanan]',
      tanggal    = '$_POST[tanggal]'
      WHERE id = '$_POST[id]'");
    echo "<script>document.location='index.php?page=arsip';</script>";
  }
  else{

    $hapus = $query = mysqli_query($koneksi, "SELECT * FROM dokumen WHERE id='$_POST[id]'");
    $nama_file=mysqli_fetch_array($hapus);
    $lokasi=$nama_file['file'];
    $hapus_file="file/$lokasi";
    unlink($hapus_file);
    move_uploaded_file($_FILES['file']['tmp_name'],'page/arsip/file/'.$file);
    $query = mysqli_query($koneksi, "UPDATE dokumen SET 
      nama = '$_POST[nama]',
      id_bulanan = '$_POST[id_bulanan]',
      tanggal    = '$_POST[tanggal]',
      file = '$file'
      WHERE id = '$_POST[id]'");
    if ($query > 0) {
      echo "<script>document.location='index.php?page=arsip';</script>";
    }
  }
?>
<?php else : ?>
<?php echo "<div class='container'>Anda tidak berhak !</div>"; ?>
<?php endif; ?>