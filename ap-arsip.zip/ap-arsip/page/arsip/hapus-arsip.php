<?php if($_SESSION['user']['level']=='admin') : ?>
<?php  
	error_reporting(0);
	$id = $_GET['id'];
	$query = mysqli_query($koneksi, "DELETE FROM dokumen WHERE id = $id");
	echo "<script>document.location='?page=arsip';</script>";
?>
<?php else : ?>
<?php echo "<div class='container'>Anda tidak berhak !</div>"; ?>
<?php endif; ?>